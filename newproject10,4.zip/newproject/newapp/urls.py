from django.urls import path, include
from . import views
from django.views.generic import TemplateView
#from django.conf.urls import url

urlpatterns = [
#for login page
    path('', views.loginpage, name='loginpage'),
#for register page
    path('register/', views.registerpage, name='registerpage'),
#for user logout
    path('logout/', views.logoutUser, name = 'logout'),
#for home pages
    path('homeAdmin/', views.homeAdmin, name='homeAdmin'),
    path('homeManager/', views.homeManager, name='homeManager'),
    path('homeCounter/', views.homeCounter, name='homeCounter'),
#for welcome pages
    path('welcomeAdmin/', views.welcomeAdmin, name='welcomeAdmin'),
    path('welcomeManager/', views.welcomeManager, name='welcomeManager'),
    path('welcomeCashier/', views.welcomeCashier, name='welcomeCashier'),
#for company page
    path('companypage/', views.companypage, name='companypage'),#get request to retrieve and display all the records
    path('companyadd/', views.companyadd, name='companyadd'),#get and post request for insert operation
    path('companyadd/<int:id>/', views.companyadd, name='companyupdate'),#get and post request for update operation
    path('companydelete/<int:id>/', views.companydelete, name='companydelete'),#delete operation
#for category page
    path('categorypage/', views.categorypage, name='categorypage'),#get request to retrieve and display all the records
    path('categoryadd/', views.categoryadd, name='categoryadd'),#get and post request for insert operation
    path('categoryadd/<slug:CategoryId>/', views.categoryadd, name='categoryupdate'),#get and post request for update operation
    path('categorydelete/<slug:CategoryId>/', views.categorydelete, name='categorydelete'),#delete operation
#for supplier page
    path('supplierpage/', views.supplierpage, name='supplierpage'),#get request to retrieve and display all the records
    path('supplieradd/', views.supplieradd, name='supplieradd'),#get and post request for insert operation
    path('supplieradd/<int:id>/', views.supplieradd, name='supplierupdate'),#get and post request for update operation
    path('supplierdelete/<int:id>/', views.supplierdelete, name='supplierdelete'),#delete operation
#for role page
    path('rolepage/', views.rolepage, name='rolepage'),#get request to retrieve and display all the records
    path('roleadd/', views.roleadd, name='roleadd'),#get and post request for insert operation
    path('roleadd/<slug:RoleCode>/', views.roleadd, name='roleupdate'),#get and post request for update operation
    path('roledelete/<slug:RoleCode>/', views.roledelete, name='roledelete'),#delete operation
#for product page
    path('productpage/', views.productpage, name='productpage'),#get request to retrieve and display all the records
    path('productadd/', views.productadd, name='productadd'),#get and post request for insert operation
    path('productadd/<slug:ProductCode>/', views.productadd, name='productupdate'),#get and post request for update operation
    path('productdelete/<slug:ProductCode>/', views.productdelete, name='productdelete'),#delete operation
#for staff page
    path('staffpage/', views.staffpage, name='staffpage'),#get request to retrieve and display all the records
    path('staffadd/', views.staffadd, name='staffadd'),#get and post request for insert operation
    path('staffadd/<slug:EmpId>/', views.staffadd, name='staffupdate'),#get and post request for update operation
    path('staffdelete/<slug:EmpId>/', views.staffdelete, name='staffdelete'),#delete operation
#for reports pages
    path('byproduct/', views.byproduct, name='byproduct'), 
    path('bydate/', views.bydate, name='bydate'),
#for help page
    path('help/', views.help, name='help'),
#for food scan page
    path('scanpage/', views.scanpage, name='scanpage'),
#for scanned products page
    path('scannedProducts/', views.scannedProducts, name='scannedProducts'),
#for cashier site products page
    path('cashierproducts/', views.cashierproducts, name='cashierproducts'),#get request to retrieve and display all the records
#for test pages
    path('addcompany/', views.addcompany, name='addcompany'),

    path('index/', views.index, name='index'),

    path('counter/', views.counter, name='counter'),
    path('testcompany/', views.testcompany, name='testcompany'),
]