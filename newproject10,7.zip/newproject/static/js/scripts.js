async function getVideo(){
    try{
        const videoSrc = await navigator.mediaDevices.getUserMedia({ video: true });
        var video = document.getElementById("video");
        video.srcObject = videoSrc;
        // video.play();
    }catch(e){
        console.log(e)
    }
}
getVideo();

var capture = document.getElementById("capture");
var canvas = document.getElementById("image");
var context = canvas.getContext('2d');

capture.addEventListener("click",function(){
    context.drawImage(video,0,0,1280,720);
});

var canvas;
function save(){
    canvas = document.getElementById('image');
    
    document.getElementById('captured_image').value = canvas.toDataURL('image/jpeg');
    console.log(document.getElementById('captured_image').value)
  
}