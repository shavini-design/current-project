from django.contrib import admin
from .models import category
from .models import company
from .models import supplier
from .models import role
from .models import staff
from .models import user
from .models import product
from .models import bill
from .models import ordered_products
# Register your models here.

admin.site.register(category)
admin.site.register(company)
admin.site.register(supplier)
admin.site.register(role)
admin.site.register(staff)
admin.site.register(user)
admin.site.register(product)
admin.site.register(bill)
admin.site.register(ordered_products)