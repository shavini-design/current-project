from django.urls import path
from . import views
from django.views.generic import TemplateView
# from django.conf.urls import url

urlpatterns = [
    path('', views.login, name='login'),
    path('homeAdmin/', views.homeAdmin, name='homeAdmin'),
    path('homeManager/', views.homeManager, name='homeManager'),
    path('welcomeAdmin/', views.welcomeAdmin, name='welcomeAdmin'),
    path('welcomManager/', views.welcomeManager, name='welcomeManager'),
    path('companypage/', views.companypage, name='companypage'),
    # path('companyedit/<int:id>', views.companyedit, name='companyedit'),

    path('categorypage/', views.categorypage, name='categorypage'),
    path('supplierpage/', views.supplierpage, name='supplierpage'),
    path('rolepage/', views.rolepage, name='rolepage'),
    path('registerpage/', views.registerpage, name='registerpage'),  
    path('productpage/', views.productpage, name='productpage'), 
    path('staffpage/', views.staffpage, name='staffpage'), 
    path('byproduct/', views.byproduct, name='byproduct'), 
    path('bydate/', views.bydate, name='bydate'),
    path('addcompany/', views.addcompany, name='addcompany'),
    # path('addsupplier/', views.addsupplier, name='addsupplier'),
    # path('editcompany/', views.editcompany, name='editcompany'),
    path('index/', views.index, name='index'),
    # path('add/', views.add, name='add'),
    # path('result/', views.result, name='result'),
    path('counter/', views.counter, name='counter'),
    path('testcompany/', views.testcompany, name='testcompany'),
]