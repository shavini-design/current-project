from django import forms
from .models import company

class CompanyForm(forms.ModelForm):

    class Meta:
        model = company
        fields = ('CompanyName','Address','City','Phone')
        labels = {
            'CompanyName':'Company Name'
        }

        def __init__(self, *args, **kwargs):
            super(CompanyForm,self).__init__(*args, **kwargs)
            self.fields['CompanyName'].required = True
            