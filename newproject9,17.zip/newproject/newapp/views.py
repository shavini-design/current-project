from django.shortcuts import render, redirect
from django.http import HttpResponse
# from django,contrib.auth.models import user, auth
from django.contrib import messages
from django.views.decorators.clickjacking import xframe_options_deny
from django.views.decorators.clickjacking import xframe_options_sameorigin
from newapp.models import company
from newapp.models import category
from newapp.models import supplier
from newapp.models import role
from newapp.models import user
from newapp.models import product
from newapp.models import staff
from newapp.models import ordered_products
from newapp.models import bill

# Create your views here.
def login(request):
    return render(request, 'newapp/login.html')

def welcomeAdmin(request):
    return render(request, 'newapp/welcomeAdmin.html')

def welcomeManager(request):
    return render(request, 'newapp/welcomeManager.html')

@xframe_options_sameorigin
def homeAdmin(request):
    return render(request, 'newapp/homeAdmin.html')

@xframe_options_sameorigin
def homeManager(request):
    return render(request, 'newapp/homeManager.html')

def companypage(request):
    if request.method == 'GET':
            results = company.objects.all            
            return render(request, 'newapp/companypage.html', {"companynames":results})
    elif request.method == 'POST':
        if request.POST.get('companyName') and request.POST.get('address') and request.POST.get('city') and request.POST.get('contactNo'):
            saverecord = company()
            saverecord.CompanyName = request.POST.get('companyName')
            saverecord.Address = request.POST.get('address')
            saverecord.City = request.POST.get('city')
            saverecord.Phone = request.POST.get('contactNo')
            saverecord.save()
            return redirect('companypage')
    else:
        print("error occured")

def companyform(request):
    return render(request, 'newapp/companyform.html')

def companyedit(request, id):
    if request.method == 'GET':
        updates = company.objects.get(id=id)
        print(updates)
        return render(request,'newapp/companyedit.html', {"updates":updates})
    elif request.method == 'POST':
        if request.POST.get('companyName') and request.POST.get('address') and request.POST.get('city') and request.POST.get('contactNo'):
            saverecord = company()
            saverecord.CompanyName = request.POST.get('companyName')
            saverecord.Address = request.POST.get('address')
            saverecord.City = request.POST.get('city')
            saverecord.Phone = request.POST.get('contactNo')
            saverecord.save()
            return redirect('companypage')
    else:
        print("error occured")

def companyupdate(request, id):
    student = get_object_or_404(Students, id=id)
    if request.method == 'GET':
        form = StudentsForm(instance=student)
        return redirect("companypage")
    else:
        form = StudentsForm(request.POST, instance=student)
        form.save()
        return redirect("/view")
    # updates = company.objects.get(id=id)
    # if request.method == 'POST':
    #     if request.POST.get('companyName') and request.POST.get('address') and request.POST.get('city') and request.POST.get('contactNo'):
    #         saverecord = company()
    #         saverecord.CompanyName = request.POST.get('updates.CompanyName')
    #         saverecord.Address = request.POST.get('updates.Address')
    #         saverecord.City = request.POST.get('updates.City')
    #         saverecord.Phone = request.POST.get('updates.Phone')
    #         saverecord.save()
    #         return redirect('companypage')
    # else:
    #     return render(request, "newapp/welcomeAdmin.html")

def categorypage(request):
    results = category.objects.all
    return render(request, 'newapp/categorypage.html', {"categorynames":results})

def supplierpage(request):
    results = supplier.objects.all
    return render(request, 'newapp/supplierpage.html', {"suppliernames":results})

def rolepage(request):
    results = role.objects.all
    return render(request, 'newapp/rolepage.html', {"rolenames":results})

def registerpage(request):
    results = user.objects.all
    outputs = role.objects.all
    return render(request, 'newapp/registerpage.html', {"users":results, "roles":outputs})

def productpage(request):
    results = product.objects.all
    outputs = category.objects.all
    outputs2 = supplier.objects.all
    return render(request, 'newapp/productpage.html', {"products":results, "categories":outputs, "suppliers":outputs2})

def staffpage(request):
    results = staff.objects.all
    outputs = role.objects.all
    outputs2 = company.objects.all
    return render(request, 'newapp/staffpage.html', {"members":results, "roles":outputs, "companies":outputs2})

def byproduct(request):
    results = ordered_products.objects.all
    return render(request, 'newapp/byproduct.html', {"productnames":results})

def bydate(request):
    results = bill.objects.all
    return render(request, 'newapp/bydate.html', {"dates":results})

def addcompany(request):
    if request.method == 'POST':
        if request.POST.get('companyName') and request.POST.get('address') and request.POST.get('city') and request.POST.get('contactNo'):
            saverecord = company()
            saverecord.CompanyName = request.POST.get('company')
            saverecord.Address = request.POST.get('address')
            saverecord.City = request.POST.get('city')
            saverecord.Phone = request.POST.get('phone')
            print("success")
            saverecord.save()
            return render(request, 'newapp/welcomeAdmin.html')
    else:
        return render(request, 'newapp/homeAdmin.html')

def index(request):
    return render(request, "newapp/counter.html")

def counter(request):
    text = request.POST['text']
    amount = len(text.split())
    return render(request,"newapp/counter.html", {'amount':amount})

def testcompany(request):
    if request.method == 'POST':
        if request.POST.get('name') and request.POST.get('address') and request.POST.get('city') and request.POST.get('phone'):
            saverecord = company()
            saverecord.CompanyName = request.POST.get('name')
            saverecord.Address = request.POST.get('address')
            saverecord.City = request.POST.get('city')
            saverecord.Phone = request.POST.get('phone')
            saverecord.save()
            return redirect('testcompany')
    else:
        return render(request, "newapp/testcompany.html")
# def add(request):
#     try:
#         print("----1---")
#         val1 = int(request.POST['num1'])
#         val2 = int(request.POST['num2'])   
#         res = val1 + val2
#         print("success")
#     except KeyError:
#         print("not success")
        
#     #return render(request, 'newapp/test.html')
#     return render(request, "result.html", {'result': val1})

# def addsupplier(request):
#     if request.method == 'POST':
#         if request.POST.get('companyName') and request.POST.get('address') and request.POST.get('city') and request.POST.get('contactNo'):
#             saverecord = company()
#             saverecord.CompanyName = request.POST.get('companyName')
#             saverecord.Address = request.POST.get('address')
#             saverecord.City = request.POST.get('city')
#             saverecord.Phone = request.POST.get('contactNo')
#             saverecord.save()
#             return render(request, 'newapp/company.html')
#     else:
#         return render(request, 'newapp/company.html')

# def editcompany(request):
#     if request.method == 'POST':
#         company = company.objects.get(id=id)
#         if request.POST.get('companyName') and request.POST.get('address') and request.POST.get('city') and request.POST.get('contactNo'):
#             saverecord = company()
#             saverecord.CompanyName = request.POST.get('companyName')
#             saverecord.Address = request.POST.get('address')
#             saverecord.City = request.POST.get('city')
#             saverecord.Phone = request.POST.get('contactNo')
#             saverecord.save()
#             return render(request, 'newapp/company.html')
#     else:
#         return render(request, 'newapp/company.html')