from django import forms
from .models import company, supplier, role, category, user, product, staff

class CompanyForm(forms.ModelForm):

    class Meta:
        model = company
        fields = ('CompanyName','Address','City','Phone')
        labels = {
            'CompanyName':'Company Name'
        }

        # def __init__(self, *args, **kwargs):
        #     super(CompanyForm,self).__init__(*args, **kwargs)
        #     self.fields['CompanyName'].required = True

class SupplierForm(forms.ModelForm):

    class Meta:
        model = supplier
        fields = ('SupplierName','Address','City','Phone')
        labels = {
            'SupplierName':'Supplier Name'
        }

class RoleForm(forms.ModelForm):

    class Meta:
        model = role
        fields = ('RoleCode','RoleName')
        labels = {
            'RoleCode':'Role Code',
            'RoleName':'Role Name'
        }

class CategoryForm(forms.ModelForm):

    class Meta:
        model = category
        fields = ('CategoryId','CategoryName')
        labels = {
            'CategoryId':'Category Id',
            'CategoryName':'Category Name'
        }

class UserForm(forms.ModelForm):

    class Meta:
        model = user
        fields = ('FirstName','LastName','UserName','Password','Email','Role')
        labels = {
            'FirstName':'First Name',
            'LastName':'Last Name',
            'UserName':'User Name'
        }
        # def __init__(self, *args, **kwargs):
        #     super(UserForm,self).__init__(*args, **kwargs)
        #     self.fields['Role'].empty_label = "Select"

class ProductForm(forms.ModelForm):

    class Meta:
        model = product
        fields = ('ProductCode','ProductName','Category','UnitPrice','SupplierId')
        labels = {
            'ProductCode':'Product Code',
            'ProductName':'Product Name',
            'UnitPrice':'Unit Price',
            'SupplierId':'Supplier Id'
        }

class StaffForm(forms.ModelForm):

    class Meta:
        model = staff
        fields = ('EmpId','Name','Role','ContactNo','Email','CompanyId')
        labels = {
            'EmpId':'Emp Id',
            'ContactNo':'Contact No',
            'CompanyId':'Company Id',
        }