from django.shortcuts import render, redirect
from django.http import HttpResponse
from .forms import CompanyForm, SupplierForm, RoleForm, CategoryForm, UserForm, ProductForm, StaffForm
# from django,contrib.auth.models import user, auth
from django.contrib import messages
from django.views.decorators.clickjacking import xframe_options_deny
from django.views.decorators.clickjacking import xframe_options_sameorigin
from newapp.models import company, category, supplier, role, user, product, staff, ordered_products, bill

# Create your views here.
def login(request):
    return render(request, 'newapp/login.html')

def welcomeAdmin(request):
    return render(request, 'newapp/welcomeAdmin.html')

def welcomeManager(request):
    return render(request, 'newapp/welcomeManager.html')

@xframe_options_sameorigin
def homeAdmin(request):
    return render(request, 'newapp/homeAdmin.html')

@xframe_options_sameorigin
def homeManager(request):
    return render(request, 'newapp/homeManager.html')

def companypage(request):
    results = company.objects.all 
    return render(request, 'newapp/companypage.html', {"companynames":results})

def companyadd(request, id=0):
    if request.method == 'GET':
        if id==0:
            form = CompanyForm()
        else:
            updates = company.objects.get(id=id)
            form = CompanyForm(instance=updates)
        return render(request, 'newapp/companyadd.html', {"form":form})
    else:
        if id==0:
            form = CompanyForm(request.POST)
        else:
            updates = company.objects.get(id=id)
            form = CompanyForm(request.POST, instance=updates)
        if form.is_valid():
            form.save()
        return redirect('companypage')

def companydelete(request, id):
    updates = company.objects.get(id=id)
    updates.delete()
    return redirect('companypage')

def categorypage(request):
    results = category.objects.all
    return render(request, 'newapp/categorypage.html', {"categorynames":results})

def categoryadd(request, CategoryId=0):
    if request.method == 'GET':
        if CategoryId==0:
            form = CategoryForm()
        else:
            updates = category.objects.get(pk=CategoryId)
            form = CategoryForm(instance=updates)
        return render(request, 'newapp/categoryadd.html', {"form":form})
    else:
        if CategoryId==0:
            form = CategoryForm(request.POST)
        else:
            updates = category.objects.get(pk=CategoryId)
            form = CategoryForm(request.POST, instance=updates)
        if form.is_valid():
            form.save()
        return redirect('categorypage')

def categorydelete(request, CategoryId):
    updates = category.objects.get(pk=CategoryId)
    updates.delete()
    return redirect('categorypage')

def supplierpage(request):
    results = supplier.objects.all
    return render(request, 'newapp/supplierpage.html', {"suppliernames":results})

def supplieradd(request, id=0):
    if request.method == 'GET':
        if id==0:
            form = SupplierForm()
        else:
            updates = supplier.objects.get(id=id)
            form = SupplierForm(instance=updates)
        return render(request, 'newapp/supplieradd.html', {"form":form})
    else:
        if id==0:
            form = SupplierForm(request.POST)
        else:
            updates = supplier.objects.get(id=id)
            form = SupplierForm(request.POST, instance=updates)
        if form.is_valid():
            form.save()
        return redirect('supplierpage')

def supplierdelete(request, id):
    updates = supplier.objects.get(id=id)
    updates.delete()
    return redirect('supplierpage')

def rolepage(request):
    results = role.objects.all
    return render(request, 'newapp/rolepage.html', {"rolenames":results})

def roleadd(request, RoleCode=0):
    if request.method == 'GET':
        if RoleCode==0:
            form = RoleForm()
        else:
            updates = role.objects.get(pk=RoleCode)
            form = RoleForm(instance=updates)
        return render(request, 'newapp/roleadd.html', {"form":form})
    else:
        if RoleCode==0:
            form = RoleForm(request.POST)
        else:
            updates = role.objects.get(pk=RoleCode)
            form = RoleForm(request.POST, instance=updates)
        if form.is_valid():
            form.save()
        return redirect('rolepage')

def roledelete(request, RoleCode):
    updates = role.objects.get(pk=RoleCode)
    updates.delete()
    return redirect('rolepage')

def userpage(request):
    results = user.objects.all
    outputs = role.objects.all
    return render(request, 'newapp/userpage.html', {"users":results, "roles":outputs})

def useradd(request, id=0):
    if request.method == 'GET':
        if id==0:
            form = UserForm()
        else:
            updates = user.objects.get(id=id)
            form = UserForm(instance=updates)
        return render(request, 'newapp/useradd.html', {"form":form})
    else:
        if id==0:
            form = UserForm(request.POST)
        else:
            updates = user.objects.get(id=id)
            form = UserForm(request.POST, instance=updates)
        if form.is_valid():
            form.save()
        return redirect('userpage')

def userdelete(request, id):
    updates = user.objects.get(id=id)
    updates.delete()
    return redirect('userpage')

def productpage(request):
    results = product.objects.all
    outputs = category.objects.all
    outputs2 = supplier.objects.all
    return render(request, 'newapp/productpage.html', {"products":results, "categories":outputs, "suppliers":outputs2})

def productadd(request, ProductCode=0):
    if request.method == 'GET':
        if ProductCode==0:
            form = ProductForm()
        else:
            updates = product.objects.get(pk=ProductCode)
            form = ProductForm(instance=updates)
        return render(request, 'newapp/productadd.html', {"form":form})
    else:
        if ProductCode==0:
            form = ProductForm(request.POST)
        else:
            updates = product.objects.get(pk=ProductCode)
            form = ProductForm(request.POST, instance=updates)
        if form.is_valid():
            form.save()
        return redirect('productpage')

def productdelete(request, ProductCode):
    updates = product.objects.get(pk=ProductCode)
    updates.delete()
    return redirect('productpage')

def staffpage(request):
    results = staff.objects.all
    outputs = role.objects.all
    outputs2 = company.objects.all
    return render(request, 'newapp/staffpage.html', {"members":results, "roles":outputs, "companies":outputs2})

def staffadd(request, EmpId=0):
    if request.method == 'GET':
        if EmpId==0:
            form = StaffForm()
        else:
            updates = staff.objects.get(pk=EmpId)
            form = StaffForm(instance=updates)
        return render(request, 'newapp/staffadd.html', {"form":form})
    else:
        if EmpId==0:
            form = StaffForm(request.POST)
        else:
            updates = staff.objects.get(pk=EmpId)
            form = StaffForm(request.POST, instance=updates)
        if form.is_valid():
            form.save()
        return redirect('staffpage')

def staffdelete(request, EmpId):
    updates = staff.objects.get(pk=EmpId)
    updates.delete()
    return redirect('staffpage')

def byproduct(request):
    results = ordered_products.objects.all
    return render(request, 'newapp/byproduct.html', {"productnames":results})

def bydate(request):
    results = bill.objects.all
    return render(request, 'newapp/bydate.html', {"dates":results})

def addcompany(request):
    if request.method == 'POST':
        if request.POST.get('companyName') and request.POST.get('address') and request.POST.get('city') and request.POST.get('contactNo'):
            saverecord = company()
            saverecord.CompanyName = request.POST.get('company')
            saverecord.Address = request.POST.get('address')
            saverecord.City = request.POST.get('city')
            saverecord.Phone = request.POST.get('phone')
            print("success")
            saverecord.save()
            return render(request, 'newapp/welcomeAdmin.html')
    else:
        return render(request, 'newapp/homeAdmin.html')

def index(request):
    return render(request, "newapp/counter.html")

def counter(request):
    text = request.POST['text']
    amount = len(text.split())
    return render(request,"newapp/counter.html", {'amount':amount})

def testcompany(request):
    if request.method == 'POST':
        if request.POST.get('name') and request.POST.get('address') and request.POST.get('city') and request.POST.get('phone'):
            saverecord = company()
            saverecord.CompanyName = request.POST.get('name')
            saverecord.Address = request.POST.get('address')
            saverecord.City = request.POST.get('city')
            saverecord.Phone = request.POST.get('phone')
            saverecord.save()
            return redirect('testcompany')
    else:
        return render(request, "newapp/testcompany.html")

