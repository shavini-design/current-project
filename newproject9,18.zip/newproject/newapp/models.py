from django.db import models
import datetime
import os

# Create your models here.
class category(models.Model):
    CategoryId = models.CharField(max_length=20, primary_key=True, blank=True,null=False)
    CategoryName = models.CharField(max_length=50, blank=True,null=False)

    def __str__(self):
        return self.CategoryName

class company(models.Model):
    CompanyId = models.IntegerField
    CompanyName = models.CharField(max_length=50, blank=True,null=False)
    Address = models.CharField(max_length=50, blank=True,null=False)
    City = models.CharField(max_length=50, blank=True,null=False)
    Phone = models.IntegerField(blank=True,null=False)

class role(models.Model):
    RoleCode = models.CharField(max_length=20, primary_key=True, blank=True,null=False)
    RoleName = models.CharField(max_length=50, blank=True,null=False)

    def __str__(self):
        return self.RoleName

class supplier(models.Model):
    SupplierId = models.IntegerField
    SupplierName = models.CharField(max_length=50, blank=True,null=False)
    Address = models.CharField(max_length=50, blank=True,null=False)
    City = models.CharField(max_length=50, blank=True,null=False)
    Phone = models.IntegerField(blank=True,null=False)

class staff(models.Model):
    EmpId = models.CharField(max_length=20, primary_key=True, blank=True,null=False)
    Name = models.CharField(max_length=50)
    Role = models.ForeignKey(role, on_delete=models.CASCADE, default=1)
    ContactNo = models.IntegerField(blank=True,null=False)
    Email = models.CharField(max_length=50)
    CompanyId = models.ForeignKey(company, on_delete=models.CASCADE, default=1)

class user(models.Model):
    UserId = models.IntegerField
    FirstName = models.CharField(max_length=50, blank=True,null=False)
    LastName = models.CharField(max_length=50, blank=True,null=False)
    Role = models.ForeignKey(role, on_delete=models.CASCADE, default=1)
    UserName = models.CharField(max_length=50, blank=True,null=False)
    Password = models.CharField(max_length=50, blank=True,null=False)
    Email = models.CharField(max_length=50, blank=True,null=False)

class product(models.Model):
    ProductCode = models.CharField(max_length=10, primary_key=True, blank=True,null=False)
    ProductName = models.CharField(max_length=50, blank=True,null=False)
    Category = models.ForeignKey(category, on_delete=models.CASCADE, default=1)
    UnitPrice = models.DecimalField(max_digits=5, decimal_places=2, blank=True,null=False)
    SupplierId = models.ForeignKey(supplier, on_delete=models.CASCADE, default=1)

class bill(models.Model):
    BillNo = models.CharField(max_length=10, primary_key=True, blank=True,null=False)
    Date = models.DateField(auto_now=False, auto_now_add=False)
    Timestamp = models.DateTimeField(auto_now=True, auto_now_add=False)
    TotalPrice = models.DecimalField(max_digits=5, decimal_places=2, blank=True,null=False)

class ordered_products(models.Model):
    Bill = models.ForeignKey(bill, on_delete=models.CASCADE, default=1)
    Product = models.ForeignKey(product, on_delete=models.CASCADE, default=1)
    Quantity = models.IntegerField(blank=True,null=False)

    class Meta:
        unique_together = ('Bill', 'Product',)