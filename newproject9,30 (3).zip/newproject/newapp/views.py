from django.shortcuts import render, redirect #added redirect
from django.http import HttpResponse
from .forms import CompanyForm, SupplierForm, RoleForm, CategoryForm, ProductForm, StaffForm #for forms
from django.contrib import messages #for messages
from django.views.decorators.clickjacking import xframe_options_deny #for iframes
from django.views.decorators.clickjacking import xframe_options_sameorigin #for iframes and edited part in settings
from newapp.models import company, category, supplier, role, product, staff, ordered_products, bill, user #for models
from .forms import UserForm, LoginForm #for authentication related forms
from django.contrib.auth import authenticate, login, logout #for authentication purpose
#for scan process
import os
import re
import io
import base64
from io import BytesIO
from PIL import Image, ImageFilter
import cv2 as cv
import numpy as np

# Create your views here.


#user registration page related
def registerpage(request):
    msg = None
    if request.method == 'POST':
        form = UserForm(request.POST)
        if form.is_valid():
            user = form.save()
            msg = 'user created'
            return redirect('registerpage')
        else:
            msg = 'form is not valid'
    else:
        form = UserForm()
    return render(request,'newapp/registerpage.html', {'form': form, 'messages': msg})

#user login page related
def loginpage(request):
    form = LoginForm(request.POST or None)
    msg = None
    if request.method == 'POST':
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None and user.Role_id=='R01':
                login(request, user)
                return redirect('homeAdmin')
            if user is not None and user.Role_id=='R02':
                login(request, user)
                return redirect('homeManager')
            if user is not None and user.Role_id=='R03':
                login(request, user)
                return redirect('homeCounter')
            else:
                msg= 'Invalid username or password'
        else:
            msg = 'error validating form'
    return render(request, 'newapp/login.html', {'form': form, 'messages': msg})

# logout user related
def logoutUser(request):
    logout(request)
    return redirect('loginpage')

#welcome pages related
def welcomeAdmin(request):
    return render(request, 'newapp/welcomeAdmin.html')

def welcomeManager(request):
    return render(request, 'newapp/welcomeManager.html')

def welcomeCashier(request):
    return render(request, 'newapp/welcomeCashier.html')

#home pages related
@xframe_options_sameorigin
def homeAdmin(request):
    return render(request, 'newapp/homeAdmin.html')

@xframe_options_sameorigin
def homeManager(request):
    return render(request, 'newapp/homeManager.html')

@xframe_options_sameorigin
def homeCounter(request):
    return render(request, 'newapp/homeCounter.html')

#company page related
def companypage(request):
    results = company.objects.all 
    return render(request, 'newapp/companypage.html', {"companynames":results})

def companyadd(request, id=0):
    if request.method == 'GET':
        if id==0:
            form = CompanyForm()
        else:
            updates = company.objects.get(id=id)
            form = CompanyForm(instance=updates)
        return render(request, 'newapp/companyadd.html', {"form":form})
    else:
        if id==0:
            form = CompanyForm(request.POST)
        else:
            updates = company.objects.get(id=id)
            form = CompanyForm(request.POST, instance=updates)
        if form.is_valid():
            form.save()
        return redirect('companypage')

def companydelete(request, id):
    updates = company.objects.get(id=id)
    updates.delete()
    return redirect('companypage')

#category page related
def categorypage(request):
    results = category.objects.all
    return render(request, 'newapp/categorypage.html', {"categorynames":results})

def categoryadd(request, CategoryId=0):
    if request.method == 'GET':
        if CategoryId==0:
            form = CategoryForm()
        else:
            updates = category.objects.get(pk=CategoryId)
            form = CategoryForm(instance=updates)
        return render(request, 'newapp/categoryadd.html', {"form":form})
    else:
        if CategoryId==0:
            form = CategoryForm(request.POST)
        else:
            updates = category.objects.get(pk=CategoryId)
            form = CategoryForm(request.POST, instance=updates)
        if form.is_valid():
            form.save()
        return redirect('categorypage')

def categorydelete(request, CategoryId):
    updates = category.objects.get(pk=CategoryId)
    updates.delete()
    return redirect('categorypage')

#supplier page related
def supplierpage(request):
    results = supplier.objects.all
    return render(request, 'newapp/supplierpage.html', {"suppliernames":results})

def supplieradd(request, id=0):
    if request.method == 'GET':
        if id==0:
            form = SupplierForm()
        else:
            updates = supplier.objects.get(id=id)
            form = SupplierForm(instance=updates)
        return render(request, 'newapp/supplieradd.html', {"form":form})
    else:
        if id==0:
            form = SupplierForm(request.POST)
        else:
            updates = supplier.objects.get(id=id)
            form = SupplierForm(request.POST, instance=updates)
        if form.is_valid():
            form.save()
        return redirect('supplierpage')

def supplierdelete(request, id):
    updates = supplier.objects.get(id=id)
    updates.delete()
    return redirect('supplierpage')

#role page related
def rolepage(request):
    results = role.objects.all
    return render(request, 'newapp/rolepage.html', {"rolenames":results})

def roleadd(request, RoleCode=0):
    if request.method == 'GET':
        if RoleCode==0:
            form = RoleForm()
        else:
            updates = role.objects.get(pk=RoleCode)
            form = RoleForm(instance=updates)
        return render(request, 'newapp/roleadd.html', {"form":form})
    else:
        if RoleCode==0:
            form = RoleForm(request.POST)
        else:
            updates = role.objects.get(pk=RoleCode)
            form = RoleForm(request.POST, instance=updates)
        if form.is_valid():
            form.save()
        return redirect('rolepage')

def roledelete(request, RoleCode):
    updates = role.objects.get(pk=RoleCode)
    updates.delete()
    return redirect('rolepage')

#product page related
def productpage(request):
    results = product.objects.all
    outputs = category.objects.all
    outputs2 = supplier.objects.all
    return render(request, 'newapp/productpage.html', {"products":results, "categories":outputs, "suppliers":outputs2})

def productadd(request, ProductCode=0):
    if request.method == 'GET':
        if ProductCode==0:
            form = ProductForm()
        else:
            updates = product.objects.get(pk=ProductCode)
            form = ProductForm(instance=updates)
        return render(request, 'newapp/productadd.html', {"form":form})
    else:
        if ProductCode==0:
            form = ProductForm(request.POST)
        else:
            updates = product.objects.get(pk=ProductCode)
            form = ProductForm(request.POST, instance=updates)
        if form.is_valid():
            form.save()
        return redirect('productpage')

def productdelete(request, ProductCode):
    updates = product.objects.get(pk=ProductCode)
    updates.delete()
    return redirect('productpage')

#staff page related
def staffpage(request):
    results = staff.objects.all
    outputs = role.objects.all
    outputs2 = company.objects.all
    return render(request, 'newapp/staffpage.html', {"members":results, "roles":outputs, "companies":outputs2})

def staffadd(request, EmpId=0):
    if request.method == 'GET':
        if EmpId==0:
            form = StaffForm()
        else:
            updates = staff.objects.get(pk=EmpId)
            form = StaffForm(instance=updates)
        return render(request, 'newapp/staffadd.html', {"form":form})
    else:
        if EmpId==0:
            form = StaffForm(request.POST)
        else:
            updates = staff.objects.get(pk=EmpId)
            form = StaffForm(request.POST, instance=updates)
        if form.is_valid():
            form.save()
        return redirect('staffpage')

def staffdelete(request, EmpId):
    updates = staff.objects.get(pk=EmpId)
    updates.delete()
    return redirect('staffpage')

#reports pages related
def byproduct(request):
    results = ordered_products.objects.all
    return render(request, 'newapp/byproduct.html', {"productnames":results})

def bydate(request):
    results = bill.objects.all
    return render(request, 'newapp/bydate.html', {"dates":results})

#help page related
def help(request):
    return render(request, 'newapp/help.html')
    
#test pages related
def addcompany(request):
    if request.method == 'POST':
        if request.POST.get('companyName') and request.POST.get('address') and request.POST.get('city') and request.POST.get('contactNo'):
            saverecord = company()
            saverecord.CompanyName = request.POST.get('company')
            saverecord.Address = request.POST.get('address')
            saverecord.City = request.POST.get('city')
            saverecord.Phone = request.POST.get('phone')
            print("success")
            saverecord.save()
            return render(request, 'newapp/welcomeAdmin.html')
    else:
        return render(request, 'newapp/homeAdmin.html')
#food scan page related
def scanpage(request):
    print("get ok")
    if request.method=="POST":
        if request.POST.get('captured_image'):
            print("post ok")
            captured_image = request.POST.get('captured_image')#get photo from frontend
            #print(captured_image)
            imgstr = re.search('base64,(.*)', captured_image).group(1)#get relevant format for storing
            #print(imgstr)
            imgstrnew = base64.b64decode(imgstr)#decode the posted data
            #print(imgstrnew)
            tempimg = Image.open(io.BytesIO(imgstrnew))#get photo from bytes
            # tempimg.show()
            os.remove('picture.jpg')#remove current photo
            tempimg.save('picture.jpg')#add new photo
            # print(tempimg.size)
            # print(tempimg.width)
            # print(tempimg.height)
            # print(tempimg.format)
            # print(tempimg.mode)
            crop_image = Image.open('picture.jpg')#open original photo
            cropped = crop_image.crop(box = (190,0,1089,719))#crop original photo
            os.remove('cropped.jpg')#remove current photo
            cropped.save('cropped.jpg')#add new cropped photo

            reduce_image = Image.open('cropped.jpg')#open cropped photo
            reduced = cropped.resize((40,32))#reduce size of the cropped photo
            os.remove('reduced.jpg')#remove current photo
            reduced.save('reduced.jpg')#add new reduced size photo

            # ///////////////////items isolation starts/////////////////////////////////////////
            bw = cv.imread('reduced.jpg',0)
            (thresh, blackAndWhiteImage) = cv.threshold(bw, 120,255, cv.THRESH_BINARY)#for night threshold=130, day=120
            invert = cv.bitwise_not(blackAndWhiteImage)#white (255) for items
            os.remove('reducedBW.jpg')
            cv.imwrite('reducedBW.jpg',invert)
           
            #data array representation of the photo
            pil_image=Image.fromarray(invert)#convert opencv image to pil image
            array = list(pil_image.getdata())#get array 0s and 1s
            # print(array)
            length = int(len(array))
            # print(length)
            zeros = 0
            ones = 0
            for item in array:
                if item == 0:#black
                    ones = ones + 1
                else:#white
                    zeros = zeros + 1
                    
            bpixels = ones
            zpixels = zeros#for all items
            print("ones: ",bpixels)
            print("zeros: ",zpixels)
            
            # ///////////////////////////////contour detection per item starts/////////////////////////////////////
            contours, hierarchy = cv.findContours(invert, cv.RETR_EXTERNAL, cv.CHAIN_APPROX_NONE)

            amount = len(contours)
            print(amount)

            #for 2 items 
            if amount == 2:
                print("two items")

                image2 = cv.drawContours(invert, contours, 0, (0, 0, 0), -1)#for indexed item get contour filled black
                cv.imwrite('contour2.jpg',image2)

                size_list = []

                pil_image2=Image.fromarray(image2)#convert opencv image to pil image
                array2 = list(pil_image2.getdata())

                # print(array)
                length = int(len(array2))
                # print(length)
                zeros = 0
                ones = 0
                for item in array2:
                    if item == 0:#black
                        ones = ones + 1
                    else:#white
                        zeros = zeros + 1
                        
                bpixels0 = ones
                zpixels0 = zeros#for indexed item
                print("ones: ",bpixels0)
                print("zeros: ",zpixels0)

                remain = zpixels - zpixels0#for remaining items except indexed item
                print("remain: ",remain)
                size_list.append(remain)#get pixel count of the first item to the array
                size_list.append(zpixels0)#get pixel count of the second item to the array
                print(size_list)

            #for 3 items
            elif amount == 3:
                print("3 items")

                image3first = cv.drawContours(invert, contours, 0, (0, 0, 0), -1)#for indexed item get contour filled black
                cv.imwrite('contour3.jpg',image3first)

                size_list = []

                pil_image3first=Image.fromarray(image3first)#convert opencv image to pil image
                array3first = list(pil_image3first.getdata())

                # print(array)
                length = int(len(array3first))
                # print(length)
                zeros = 0
                ones = 0
                for item in array3first:
                    if item == 0:#black
                        ones = ones + 1
                    else:#white
                        zeros = zeros + 1
                        
                bpixels1 = ones
                zpixels1 = zeros#for indexed item
                print("ones: ",bpixels1)
                print("zeros: ",zpixels1)

                first = zpixels - zpixels1#for remaining items except indexed item
                print("first: ",first)
                size_list.append(first)#get pixel count of the first item to the array
                # size_list.append(zpixels0)#get pixel count of the second item to the array

                image3second = cv.drawContours(invert, contours, 1, (0, 0, 0), -1)
                cv.imwrite('contour3second.jpg',image3second)

                pil_image3second=Image.fromarray(image3second)#convert opencv image to pil image
                array3second = list(pil_image3second.getdata())

                # print(array)
                length = int(len(array3second))
                # print(length)
                zeros = 0
                ones = 0
                for item in array3second:
                    if item == 0:#black
                        ones = ones + 1
                    else:#white
                        zeros = zeros + 1
                        
                bpixels2 = ones
                zpixels2 = zeros#for indexed item
                print("ones: ",bpixels2)
                print("zeros: ",zpixels2)

                remain = zpixels - first#for remaining items except indexed item
                second = remain-zpixels2
                third = zpixels - (first + second)
                print("second: ",second)
                print("third: ",third)
                size_list.append(second)
                size_list.append(third)
                print(size_list)

            #for 4 items
            elif amount == 4:
                print("4 items")

            return redirect('scanpage')

    else:
        return render(request, 'newapp/scanpage.html')

def index(request):
    return render(request, "newapp/counter.html")

def counter(request):
    text = request.POST['text']
    amount = len(text.split())
    return render(request,"newapp/counter.html", {'amount':amount})

def testcompany(request):
    if request.method == 'POST':
        if request.POST.get('name') and request.POST.get('address') and request.POST.get('city') and request.POST.get('phone'):
            saverecord = company()
            saverecord.CompanyName = request.POST.get('name')
            saverecord.Address = request.POST.get('address')
            saverecord.City = request.POST.get('city')
            saverecord.Phone = request.POST.get('phone')
            saverecord.save()
            return redirect('testcompany')
    else:
        return render(request, "newapp/testcompany.html")

