from django.shortcuts import render
from django.http import HttpResponse
from django.views.decorators.clickjacking import xframe_options_deny
from django.views.decorators.clickjacking import xframe_options_sameorigin

# Create your views here.
def login(request):
    return render(request, 'newapp/login.html')

def welcomeAdmin(request):
    return render(request, 'newapp/welcomeAdmin.html')

def welcomeManager(request):
    return render(request, 'newapp/welcomeManager.html')

def category(request):
    return render(request, 'newapp/category.html')

def company(request):
    return render(request, 'newapp/company.html')

def register(request):
    return render(request, 'newapp/register.html')

def role(request):
    return render(request, 'newapp/role.html')

def supplier(request):
    return render(request, 'newapp/supplier.html')

@xframe_options_sameorigin
def homeAdmin(request):
    return render(request, 'newapp/homeAdmin.html')

@xframe_options_sameorigin
def homeManager(request):
    return render(request, 'newapp/homeManager.html')